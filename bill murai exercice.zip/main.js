const range = document.getElementById('exoRange');
const imageOne= document.getElementById('image-one');
const imageTwo = document.getElementById('image-two');
range.value = 0;
range.addEventListener('input', function(){
    let chValue = range.value;
    imageTwo.style.opacity = 1 - chValue / 10;
    imageOne.style.opacity = 1 + chValue / 10;
})
